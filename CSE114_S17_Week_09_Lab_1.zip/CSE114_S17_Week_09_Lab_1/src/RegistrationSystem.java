
public class RegistrationSystem {
	StudentRecord[] students;
	int nos;
	final int MAX_NUM_STUDENTS = 1000;
	
	RegistrationSystem() {
		students = new StudentRecord[MAX_NUM_STUDENTS];
	}
	
	void addStudent(StudentRecord s) {
		students[nos] = s;
		nos++;
	}
	
	// Return the student object whose attribute id is 'id'.
	// Return null if the id does not exist.
	StudentRecord getStudent(String id) {
		StudentRecord rec = null;
		
		// Re-assign the StudentRecord object rec with
		// its attribute id equal to parameter id.
		// If not found, rec remains null
		
		for(int i = 0; i < nos; i ++) {
			if(students[i].id.equals(id)) {
				rec = students[i];
			}
		}
		
		return rec;
	}
}









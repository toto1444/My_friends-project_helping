
public class RegistrationSystemTester {
	public static void main(String[] args) {
		Course cse114ForAlan = new Course("CSE114 Computer Science I");
		cse114ForAlan.setMandatory(true);
		cse114ForAlan.setNumberOfCredits(4);
		// System.out.println(cse114); this will print out the address
		System.out.println(cse114ForAlan.getStringValue());
		
		Course cse214ForAlan = new Course("CSE214 Computer Science II");
		cse214ForAlan.setMandatory(false);
		cse214ForAlan.setNumberOfCredits(3);
		System.out.println(cse214ForAlan.getStringValue());
		
		StudentRecord alan = new StudentRecord("id1", "Alan", "Cooper");
		alan.register(cse114ForAlan);
		alan.register(cse214ForAlan);
		System.out.println(alan.courses.length);
		System.out.println(alan.noc);
		
		Course[] coursesOfAlan = alan.getRegisteredCourses();
		System.out.println("Alan is taking " + coursesOfAlan.length + " courses");
		System.out.print("First course of Alan:");
		System.out.println(coursesOfAlan[0].getStringValue());
		// alternatively, you can also write: alan.courses[0].getStringValue()
		
		// aliasing: the following paths refer to the same object
		// 1. coursesOfAlan[0]
		// 2. alan.courses[0]
		// 3. cse114ForAlan
		coursesOfAlan[0].setLetterGrade("A");
//		alan.courses[0].setLetterGrade("A");
//		cse114ForAlan.setLetterGrade("A");
		coursesOfAlan[1].setLetterGrade("F");
		
		System.out.println(alan.getStringValue());
		
		StudentRecord mark = new StudentRecord("id2", "Mark", "Lawford");
		
		RegistrationSystem sys = new RegistrationSystem();
		sys.addStudent(alan);
		sys.addStudent(mark);
		// id1 denotes the StudentRecord of Alan
		StudentRecord r1 = sys.getStudent("id1");
		System.out.println("Record of Alan in the system is:");
		System.out.println(r1.getStringValue());
		StudentRecord r2 = sys.getStudent("junk");
		System.out.println("Record of unknown record with id junk:");
		System.out.println(r2);
	}
}







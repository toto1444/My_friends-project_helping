
public class StudentRecord {
	String id;
	String firstName;
	String lastName;
	String programOfStudy;
	int yearOfEntrance;
	int yearOfGraduation;
	final int MAX_NUM_COURSES = 5;

	StudentRecord(String id, String fn, String ln) {
		this.id = id;
		this.firstName = fn;
		lastName = ln;
		// initialize the courses attribute
		courses = new Course[MAX_NUM_COURSES];
	}

	// Each element in this array stores
	// the address of some Course object.
	// You can use the DOT notation to access
	// attributes of the Course class.
	Course[] courses; 
	int noc; // number of courses

	// add a course for student
	void register(Course c) {
		// if we did not initialize the courses array
		// in the constructor, we would get a NullPointerException
		// when indexing into 'courses'
		courses[noc] = c;
		noc ++;
	}

	// add a course, denoted by its name, for student
	void register(String name) {
		Course c = new Course(name);
		courses[noc] = c;
		noc ++;
	}

	// Define an accessor method that returns 
	// the courses registered so far.
	Course[] getRegisteredCourses() {
		// return courses is not satisfactory,
		// because when noc < courses.length,
		// we have null slots in the courses array.
		Course[] cs = new Course[noc];
		for(int i = 0; i < noc; i ++) {
			cs[i] = courses[i];
		}
		return cs;
	}

	String getStringValue() {
		String s = "";
		s += firstName + " is taking " + noc + " courses:\n";
		for(int i = 0; i < this.noc; i ++) {
			Course c = this.courses[i];
			// reuse the getStringValue method from Course
			s += "\t" + c.getStringValue() + "\n";
		}
		s += firstName + " has GPA: " + getGPA();
		return s;
	}
	
	double getGPA() {
		double totalGP = 0;
		
		for(int i = 0; i < noc; i ++) {
			Course c = this.courses[i];
			String lg = c.getLetterGrade();
			double gp = getGradePoint(lg);
			totalGP += gp;
		}
		
		double gpa = totalGP / noc;
		return gpa;
	}
	
	// Helper method for converting letter grade to grade point
	double getGradePoint(String lg) {
		double gp = 0.0;
		if(lg.equals("A")) {
			gp = 8.0;
		}
		else if(lg.equals("B")) {
			gp = 7.0;
		}
		else if(lg.equals("C")) {
			gp = 6.0;
		}
		else { /* F */
			gp = 5.0;
		}
		return gp;
	}
}







